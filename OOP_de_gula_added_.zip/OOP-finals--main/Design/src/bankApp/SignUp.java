package bankApp;

import java.awt.event.ActionListener;

public class SignUp extends JFrame  implements ActionListener{

}
